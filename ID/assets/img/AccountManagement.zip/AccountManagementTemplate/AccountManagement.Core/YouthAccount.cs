﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountManagement.Core
{
    public class YouthAccount : Account
    {
        /// <summary>
        /// Beim Erzeugen eines Jugendkontos werden 50€ Startbonus gutgeschrieben
        /// </summary>
        /// <param name="accountNumber"></param>
        public YouthAccount(int accountNumber) : base(accountNumber)
        {
            Balance = 50;
        }

        /// <summary>
        /// Ein Überziehen des Jugendkontos ist nicht möglich
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override bool RaiseFrom(double amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException("Der Betrag muss größer als 0 sein!");
            else if (Balance - amount >= 0)
            {
                Balance = Balance - amount;
                return true;
            }
            return false;
        }
    }
}
