﻿using System;

namespace AccountManagement.Core
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Only Unittests!");
        }
    }
}
