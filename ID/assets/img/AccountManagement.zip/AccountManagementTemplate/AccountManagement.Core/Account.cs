﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountManagement.Core
{
    public class Account
    {
        private const double MAXOVERDRAFT = -1000.0;
        int _accountNumber;
        double _balance;

        public int AccountNumber
        {
            get { return _accountNumber; }
            set 
            { 
                _accountNumber = value;
            }
        }

        public double Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }

        /// <summary>
        /// Anlegen eines neuen Kontos
        /// </summary>
        /// <param name="accountNumber"></param>
        public Account(int accountNumber)
        {
            if (accountNumber <= 0)
                throw new ArgumentOutOfRangeException("Die Kontonummer muss eine Ganzzahl größer 0 sein!");

            if (IsValid(accountNumber))
                AccountNumber = accountNumber;
            else
                throw new ArgumentException("Kontonummer ist ungültig!");
        }

        /// <summary>
        /// Die Kontonummer ist gültig, wenn ihre Ziffernsumme durch 10 teilbar ist
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public static bool IsValid(int accountNumber)
        {
            string accNrAsString = accountNumber.ToString();
            int digitSum = 0;

            for (int i = 0; i < accNrAsString.Length; i++)
            {
                digitSum += accNrAsString[i] - '0';
            }

            if (digitSum % 10 == 0)
                return true;

            return false;
        }

        /// <summary>
        /// Auf das Konto wird der Betrag eingezahlt
        /// </summary>
        /// <param name="amount">Betrag muss größer als 0 sein</param>
        public void PayIn(double amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException("Der Betrag muss größer als 0 sein!");
            else
                Balance = Balance + amount;
        }

        /// <summary>
        /// Abhebung des Betrags vom Konto
        /// </summary>
        /// <param name="amount">Betrag muss größer als 0 sein</param>
        /// <returns>War die Abhebung möglich (Konto gedeckt)</returns>
        public virtual bool RaiseFrom(double amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException("Der Betrag muss größer als 0 sein!");
            else
            {
                if (Balance - amount >= MAXOVERDRAFT)
                {
                    Balance = Balance - amount;
                    return true;
                }
            }

            return false;
        }
    }
}
